<div class="sidebar">
            <img class="img" src="../assets/img/RUS.png">

            <a href="#dashboard"> Dashboard</a>
            <a href="order.php">Order</a>
            <a href="#analytics">Analytics</a>
            <a href="#revenue">Revenue</a>
            <a href="#stats">Stats</a>
            <a href="customer.php">Customers</a>
            <a href="#vendors">Vendors</a>
        </div>