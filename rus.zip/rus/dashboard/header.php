<div class="header">
    <div class="brand">
        <img class="img" src="../assets/img/RUS.png">

        <h3 class="brand">RUS</h3>
    </div>
    <div class="list">

        <a href="index.php"> Dashboard</a>
        <a href="order.php">Order</a>
        <a href="#analytics">Analytics</a>
        <a href="#revenue">Revenue</a>
        <a href="#stats">Stats</a>
        <a href="customer.php">Customers</a>
        <a href="#vendors">Vendors</a>
    </div>
    <div class="acc_set">
        <a href="#settings">Settings</a>
        <a href="#account">Account</a>
        <a href="../assets/php/alogout.php">Logout</a>

    </div>
</div>
</div>