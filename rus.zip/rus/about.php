<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About US</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;1,100;1,300;1,400;1,500&family=Ubuntu:ital,wght@0,700;1,500&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
</head>

<body>
    <!-- As a heading -->
    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid text-center">
            <span class="navbar-brand mb-0 h1 ">About US</span>
        </div>
    </nav>
    <div class="container-fluid">
        <div class="center-section" style="margin:20px auto;width:75%">
            <h2>Welcome to RUS Electronics</h2>
            <p> We offer a competitive service for your repaired electronic goods at
                affordable cost
                using skillful technician in the market. We are glad to inform you that, not only us(RUS), the service
                will be provided by
                the skillful retailer in your very near locality whom will have a tie up with RUS. We never compromise
                on our quality of service that we try to give 
                our best service in Cost effective, Durability of spares, On Time, Technical Support.</p>
            <p>RUS was founded in the year 2021, in a small living room. We two friends who are engineering graduates in
                the field of Mechatronics Engineering,
                started this with a great vision infront.
            </p>
            <p>We never wanted to grow alone. We wish to be forest. So we are glad in inviting may local retailers to join
                us and we wish to provide them a market
                space and also for customers not to get lost in getting your devices repaired.
            </p>
            <p>We help you to get your device get ready.</p>
            <h4>Thank You.</h4>
            <div class="end_credit" style="float:right">

                <p>with True note</p>
                <div class="2-col" style="display:flex;gap:10px;">
                   <h6>RUS Team</h6>
                </div>
            </div>
        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
    integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
</script>

</html>