<?php
require_once('connection.php');

$sql1="Select * from registration";
$result = mysqli_query($con, $sql1);
$row_count =  mysqli_num_rows ($result);
?>