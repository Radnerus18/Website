<?php

require_once('connection.php');
$id=$_POST['id'];
// echo $id;
// die();
?>