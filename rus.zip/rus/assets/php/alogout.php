<?php

session_destroy();
header('Location:../../dashboard/index.php');

?>