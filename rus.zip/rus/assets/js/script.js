function qssubmit() {
    var fullname = document.getElementById("fullname").value;
    var mail = document.getElementById("mail").value;
    var phonenum = document.getElementById("phonenum").value;
    var address = document.getElementById("address").value;
    var pincode = document.getElementById("pincode").value;
    var deviceselect = document.getElementById("deviceselect").value;
    var brandname = document.getElementById("brandname").value;
    var problemdescription = document.getElementById("problemdescription").value;
    var exampleCheck1 = document.getElementById("exampleCheck1").value;
    // alert(exampleCheck1);
    if (fullname != "" && mail != "" && phonenum != "" && address != "" && pincode != "" &&
        deviceselect != "" && brandname != "" && problemdescription != "" && exampleCheck1 != "") {
        alert("Submitted \n You get a call from RUS in 15 mins.\n Thank You");
        // swal("Submitted")
    } else {
        swal({
            title: "Fields Empty!!",
            text: "Please fill the valid data!",
            icon: "warning",
            button: "Ok"
        });
    }


}

function help_submit() {
    var human_name = document.getElementById("human_name").value;
    var Order_id = document.getElementById("Order_id").value;
    var message_text = document.getElementById("message_text").value;
    if (human_name != "" && Order_id != "" && message_text != "") {
        alert("Sent\n You will get a call in 15 minutes \n Thank You")
    } else {
        swal({
            title: "Fields Empty!!",
            text: "Please fill the valid data!",
            icon: "warning",
            button: "Ok"
        });
    }
}

function feedback_submit() {
    var feedback_name = document.getElementById("feedback_name").value;
    var feedback_msg = document.getElementById("feedback_msg").value;

    if (feedback_name != "" && feedback_msg != "") {
        alert("Thanks for your Feedback.")
    } else {
        alert("Please fill the data.")
    }
}