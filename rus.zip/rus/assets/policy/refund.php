<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Refund Policy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;1,100;1,300;1,400;1,500&family=Ubuntu:ital,wght@0,700;1,500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/400media.css">
    <link rel="stylesheet" href="../css/600media.css">
    <link rel="stylesheet" href="../css/767media.css">
    <link rel="stylesheet" href="../css/900media.css">
    <link rel="stylesheet" href="../css/1300media.css">
    <link rel="stylesheet" href="../css/big_media.css">
</head>

<body>
    <!-- As a heading -->
    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid text-center">
            <span class="navbar-brand mb-0 h1 ">Refund Policy</span>
        </div>
    </nav>
    <div class="container-fluid">
        <div class="center-section" style="margin:20px auto;width:75%">
            <h2>Refund or Free Service Policy for Customer</h2>
            <p>Hi our beloved customer. We RUS are tyring to give you the best repair service for your electronics devices. As per our Policy we will be returning 100% of your money within 2 business days only in any of these scenarios.
            </p>
            <ol>
                <li>If the same problem i.e the problem that the respective device came to us for the first time occurs again within <b>30 days</b> from the time of delivery after service will be dealt with free service according to the <b>Warranty</b> issued
                    by us or money will be refunded.
                </li>
                <li>
                    If the spare changed during our service troubles or damaged only without your (i.e user of that device) within <b>15 days</b> from the time of delivery after service will be considered for free service or refund.
                </li>
                <li>
                    We will be doing QC(Quality Check) after the service for each and every material. Incase any defaults happened on our side or our Vendor can be claimed for compensation with proof.
                </li>
                <li>
                    No self handling of serviced material is encouraged after service to get refund. Only material get damaged and defaulted on our side or our Vendor will be considered for refunding.
                </li>
                <li>
                    To get refund click this <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        Refund
                      </button>
                </li>
            </ol>
            <!-- Button trigger modal -->
            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Fill this form</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form class="row g-3" action="../php/refund.php" method="POST">
                                <div class="col-md-6">
                                <label for="inputEmail4" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="refund_mail" name="refund_mail">
                                   
                                </div>
                                <div class="col-md-6">
                                <label for="Number" class="form-label">Phone Number</label>
                                    <input type="password" class="form-control" id="refund_phone" name="refund_phone">
                                   
                                </div>
                                <div class="col-md-6">
                                <label for="Service_id" class="form-label">Service_id</label>
                                    <input type="text" class="form-control" id="refund_id" name="refund_id" placeholder="Id given at delivery invoice">
                                </div>
                                <div class="col-md-6">
                                <label for="Name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="refund_name" name="refund_name" placeholder="Your Name">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlTextarea1" class="form-label">Reason for Refund</label>
                                    <textarea class="form-control" id="refund_msg" name="refund_msg" placeholder="Enter the problem you faced" rows="3"></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary" onclick="refund()">Send</button>
                            </form>
                        </div>
                        
                    </div>
                </div>
            </div>
            <h4>Thank You.</h4>
            <div class="end_credit" style="float:right">

                <p>with True note</p>
                <div class="2-col" style="display:flex;gap:10px;">
                    <h6>RUS Team</h6>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
</script>
<script>
    function refund() {
    var refund_name = document.getElementById("refund_name").value;
    var refund_id = document.getElementById("refund_id").value;
    var refund_mail = document.getElementById("refund_mail").value;
    var refund_phone = document.getElementById("refund_phone").value;
    var refund_msg = document.getElementById("refund_msg").value;

    if (refund_name != "" && refund_id != "" && refund_mail  != "" && refund_phone != "" && refund_msg != "") {
        alert("Thanks for your message.\n You will contacted by our executive shortly.\n Thank You.")
    } else {
        alert("Please fill the data.")
    }
}
</script>
</html>